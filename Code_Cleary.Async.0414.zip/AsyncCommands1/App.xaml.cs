﻿using System.Windows;

namespace AsyncCommands
{
    public partial class App : Application
    {
    }
}